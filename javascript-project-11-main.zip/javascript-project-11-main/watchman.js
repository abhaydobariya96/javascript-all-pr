
let val = JSON.parse(localStorage.getItem('chackuser'));
if (!val){
    alert('pela login to karto avne')
    window.location.href="login.html"
}
    


